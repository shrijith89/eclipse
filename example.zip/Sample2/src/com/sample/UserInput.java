package com.sample;

import java.util.Scanner;

class useinput{
	public void method() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		int a = sc.nextInt();
		System.out.println("Enter the second number");
		int b = sc.nextInt();
		System.out.println("The sum is "+ (a+b));
	}
}
public class UserInput {
	public static void main(String[] args) {
		useinput obj = new useinput();
		obj.method();
	}

}
