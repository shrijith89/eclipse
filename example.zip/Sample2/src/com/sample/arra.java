package com.sample;

@FunctionalInterface
interface abc{
	int a=10;
	public void method();
	default void ydemo() {
		System.out.println("hello check in abc interface");
	}
}


interface abd extends abc{
	default void ydemo() {
		System.out.println("Second ");
	}
}

class a implements abd,abc{

	public void method() {
		System.out.println("hello");
		
	}
	
}

class ac{
	static void hello() {
		System.out.println("hello world");
	}
}

public class arra {
	public static void main(String[] args) {
		abc obj = new a();
		obj.ydemo();
		ac obj1 = new ac();
		obj1.hello();
			}
	}

