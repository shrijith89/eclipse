package practiceexamples;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Picture {
public static void main(String[] args) throws IOException {
	WebDriverManager.chromedriver().setup();
	ChromeOptions c = new ChromeOptions();
	c.addArguments("disable-infobars");
	
	WebDriver driver = new ChromeDriver(c);
	driver.get("https://www.google.com");
	File file = ((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(file,new File("Output.png"));
	DesiredCapabilities dc = new DesiredCapabilities();
	
}
}
