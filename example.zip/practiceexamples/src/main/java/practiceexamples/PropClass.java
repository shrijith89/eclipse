package practiceexamples;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PropClass {
	public static void main(String[] args) throws IOException {
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream("C:\\Users\\PSShrijith\\eclipse-workspace1\\practiceexamples\\src\\main\\resources\\example.properties");
		prop.load(file);
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		System.out.println(prop.getProperty("url"));
		driver.get(prop.getProperty("url"));
		
	}

}
