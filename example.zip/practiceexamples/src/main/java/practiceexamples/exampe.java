package practiceexamples;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class exampe {
public static void main(String[] args) {
	Set<Integer> set = new HashSet<>();
	set.add(10);
	set.add(90);
	set.add(1000);
	set.add(89);
	
	WebDriver driver = new HtmlUnitDriver();
	
	Iterator<Integer> it = set.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
	}
}
}
