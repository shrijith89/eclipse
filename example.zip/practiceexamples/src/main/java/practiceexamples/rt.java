package practiceexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class rt {
public static void main(String[] args) {
	WebDriverManager.chromedriver().setup();
	WebDriver driver = new ChromeDriver();
	driver.get("https://getbootstrap.com/docs/4.0/components/dropdowns/");
	driver.findElement(By.xpath("//button[@id=\"dropdownMenuButton\"]")).click();
}
}
