package practiceexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class exampel {
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_radio");
		//driver.get("https://www.salesforce.com/in/form/signup/freetrial-sales/?d=70130000000Enyk");
//		WebElement drop = driver.findElement(By.xpath("//select[@name='CompanyEmployees']"));
//		Select select = new Select(drop);
//		drop.click();
//		select.selectByValue("250");
//		drop.sendKeys(Keys.ESCAPE);
//		Thread.sleep(2000);
		Thread.sleep(14000);
		WebElement check = driver.findElement(By.xpath("//*[@id=\"css\"]"));
		check.click();
		
		}
}
