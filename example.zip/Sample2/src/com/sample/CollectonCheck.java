package com.sample;

import java.util.ArrayList;
import java.util.Collection;

public class CollectonCheck {
	public static void main(String[] args) {
		Collection<Object> list = new ArrayList<>();
	}

}
