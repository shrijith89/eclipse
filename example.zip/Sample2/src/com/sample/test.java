package com.sample;

class Calc {
	public void mymethod() {
		System.out.println("hello world");
	}

	static class InnerClass {
		public void mymethod() {
			System.out.println("My second method");
		}
	}
}

public class test {
	public static void main(String[] args) {
		Calc calc = new Calc();
		//Calc.InnerClass obj = calc.new InnerClass();
		Calc.InnerClass obj = new Calc.InnerClass(); 
		obj.mymethod();
	}
}
