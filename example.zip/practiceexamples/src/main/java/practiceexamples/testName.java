package practiceexamples;

public @interface testName {

}
