package practiceexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SampleExec {
	WebDriver driver;

	@AfterSuite
	public void test() {
		System.out.println("This is after suite method");
	}
	
	@BeforeSuite
	public void test1() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://recruit.talview.com");
		Thread.sleep(10000);
		//System.out.println("This is before suite method");
	}
	
	
	@BeforeMethod
	public void test2() {
		System.out.println("This is before method");
	}
	
	@AfterMethod
	public void test3() {
		System.out.println("This is after method");
	}
	
	
	@Test(dataProvider ="check")
	//@Parameters({"a","b"})
	public void a(String a, String b) throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys(a);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(b);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@placeholder='Email']")).clear();
		driver.findElement(By.xpath("//input[@id='password']")).clear();
		Thread.sleep(10000);
	}
	
	
	@DataProvider(name="check")
	public Object[][] mymethod(){
		return new Object[][] {{"devtesting@talview.com","devtesting@5001"},{"p.shrijith@talview.com","6067703262pSS!"}};
	}
	
	@Test
	public void b() {
		System.out.println("This is test 2");
	}
	
	@Test
	public void aa() {
		System.out.println("This is method 2 now");
	}
}
