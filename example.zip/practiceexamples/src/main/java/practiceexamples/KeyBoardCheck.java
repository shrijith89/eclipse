package practiceexamples;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KeyBoardCheck {
	public static void main(String[] any) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://app.copyleaks.com/text-compare");
		
		WebElement main = driver.findElement(By.xpath("//*[@id=\"mat-tab-content-0-0\"]/div/div/quill-editor/div[2]/div[1]"));
		main.click();
		main.sendKeys("Hello World");
		main.sendKeys(Keys.CONTROL+"a");
		main.sendKeys(Keys.CONTROL+"c");
		Actions action = new Actions(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(1000));
		WebElement wait = new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(By.xpath("")));
		
		Wait<WebDriver> wait1 = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(10)).pollingEvery(Duration.ofSeconds(10)).withMessage("check");
		WebElement element2 = driver.findElement(By.xpath("//*[@id=\"mat-tab-content-1-0\"]/div/div/quill-editor/div[2]/div[1]"));
		element2.click();
		element2.sendKeys(Keys.CONTROL+"v");
		WebElement wait6 = new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(By.xpath(" ")));
		Wait<WebDriver> wait5 = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(10)).pollingEvery(Duration.ofSeconds(10));

	}

}
