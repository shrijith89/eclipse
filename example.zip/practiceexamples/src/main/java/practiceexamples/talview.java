package practiceexamples;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class talview {
public static void main(String[] args) throws InterruptedException {
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://recruit.talview.dev");
	Thread.sleep(3000);
	driver.manage().window().maximize();
	driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("devtesting@talview.com");
	driver.findElement(By.xpath("//input[@id='password']")).sendKeys("devtesting@5001");
	driver.findElement(By.xpath("//button[text()='Sign In']")).click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("//a[text()='Assessments']")).click();
	Thread.sleep(10000);
	driver.findElement(By.xpath("//tbody/tr[1]/td")).click();
	Actions action = new Actions(driver);
	String selectAll = Keys.chord(Keys.CONTROL, "a");
	Thread.sleep(5000);
	driver.findElement(By.xpath("//div/a[text()='Objective Test']")).click();
	
}
}
